﻿VARSTOCASES
  /ID=case
  /MAKE response FROM y1 y2 y3 y4 y5 y6 y7 y8 y9 y10 y11 y12 y13 y14 y15
  /INDEX=itemnr(15) 
  /KEEP=x1 x2 ID
  /NULL=KEEP.

IF itemnr = 1 y1 = response.
IF itemnr = 2 y2 = response.
IF itemnr = 3 y3 = response.
IF itemnr = 4 y4 = response.
IF itemnr = 5 y5 = response.
IF itemnr = 6 y6 = response.
IF itemnr = 7 y7 = response.
IF itemnr = 8 y8 = response.
IF itemnr = 9 y9 = response.
IF itemnr = 10 y10 = response.
IF itemnr = 11 y11 = response.
IF itemnr = 12 y12 = response.
IF itemnr = 13 y13 = response.
IF itemnr = 14 y14 = response.
IF itemnr = 15 y15 = response.
EXECUTE.
